import MainRouter from "./components/mainRouter";

function App() {
  return (
    <>
      <MainRouter />
    </>
  );
}
export default App;
